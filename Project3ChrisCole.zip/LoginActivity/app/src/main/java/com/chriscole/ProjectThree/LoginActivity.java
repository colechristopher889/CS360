package com.chriscole.ProjectThree;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.chriscole.loginactivity.R;

public class LoginActivity extends AppCompatActivity {

    private EditText txtUsername;
    private EditText txtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtUsername = findViewById(R.id.txtUsername);
        txtPassword = findViewById(R.id.txtPassword);

        Button btnLogin = (Button)findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(listener -> handleLogin());
    }

    private void handleLogin(){
        String username = txtUsername.getText().toString();
        String password = txtPassword.getText().toString();

        if (DatabaseManager.getInstance(getApplicationContext()).authenticate(username, password)){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);

        }else {
            Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_LONG).show();
        }
    }
}
